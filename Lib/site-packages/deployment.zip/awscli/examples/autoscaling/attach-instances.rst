**To attach an instance to an Auto Scaling group**

This example attaches the specified instance to the specified Auto Scaling group::

    aws autoscaling attach-instances --instance-ids i-93633f9b --auto-scaling-group-name my-auto-scaling-group
